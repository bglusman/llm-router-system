FROM node:18-alpine

RUN apk add --no-cache curl python3 py3-pip

WORKDIR /app

# Copy package files
COPY package*.json ./

# Smart dependency installation
RUN set -ex; \
    if [ -f package-lock.json ]; then \
        echo "📦 Installing with npm ci..."; \
        npm ci --only=production; \
    elif [ -f yarn.lock ]; then \
        echo "📦 Installing with yarn..."; \
        npm install -g yarn; \
        yarn install --frozen-lockfile --production; \
    else \
        echo "📦 Installing with npm install..."; \
        npm install --only=production; \
    fi

# Rest of Dockerfile...

